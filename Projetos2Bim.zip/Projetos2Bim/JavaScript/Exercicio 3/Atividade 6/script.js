let inputNumber1 = document.querySelector("#inputNumber1")
let btCalcular = document.querySelector("#btCalcular")
let resultado = document.querySelector("#resultado")

function calculoQuilos(){
    let num1 = Number(inputNumber1.value)
    let result = (num1 * 12);

    resultado.innerHTML = "Valor total a pagar: " + result + " Reais";
}

btCalcular.onclick = function (){
    calculoQuilos();
}