let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoDias(){
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);
    let mes = (num2 * 30 - 30 + num1);
    
    resultado.innerHTML = ("Já se passaram " + mes + " dias desde o começo do ano.");

}

btCalcular.onclick = function (){
    calculoDias();
}