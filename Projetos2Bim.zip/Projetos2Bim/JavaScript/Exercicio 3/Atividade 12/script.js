let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoCDU(){
    let num1 = Number(inputNumber1.value);
    let centena = (num1);
    let dezena = (num1 % 100);
    let unidade = (num1 % 10);

    resultado.innerHTML = "Centena: " + centena + "<hr>" +
                          "Dezena: " + dezena + "<hr>" +
                          "Unidade: " + unidade + "<hr>";
}

btCalcular.onclick = function (){
    calculoCDU();
}