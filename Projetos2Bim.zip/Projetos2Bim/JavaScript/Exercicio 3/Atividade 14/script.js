let inputNumber1 = document.querySelector("#inputNumber1");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoConta(){
    let valorConta = Number(inputNumber1.value);
    let valorCarlos = Math.floor(valorConta / 3);
    let valorAndre = Math.floor(valorCarlos);
    let valorFelipe = (valorConta - valorCarlos - valorAndre);

    resultado.innerHTML = "Carlos pagará: " + valorCarlos + "<br>" + "<hr>" +
                          "André pagará: " + valorAndre + "<br>" + "<hr>" +
                          "Felipe pagará: " + valorFelipe + "<hr>";
}

btCalcular.onclick = function (){
    calculoConta();
}