let inputNumber1 = document.querySelector("#inputNumber1");
let inputNumber2 = document.querySelector("#inputNumber2");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calculoPoupanca(){
    let num1 = Number(inputNumber1.value);
    let num2 = Number(inputNumber2.value);
    let result = ((num1 * 0.12) + (num2 * 1.50));
    
    resultado.innerHTML = 
    "<p>Valor total arrecadado:</p>" + (result) + 
    "<p>Valor a guardar na poupança de 10% do valor total arrecadado:</p>" + ((10 * result) / 100);
}

btCalcular.onclick = function (){
    calculoPoupanca();
}
