let saldo = document.querySelector("#saldo");
let btsomar = document.querySelector("#btsomar");
let resultado = document.querySelector("#resultado");

function trocarNumero() {
    let valorSaldo = Number(saldo.value);
    let reajuste = valorSaldo * 0.01;
    let novoSaldo = valorSaldo + reajuste;

    resultado.textContent = "O saldo com reajuste de 1% e: " + novoSaldo.toFixed(2);
}

btsomar.onclick = function() {
    trocarNumero();
}
