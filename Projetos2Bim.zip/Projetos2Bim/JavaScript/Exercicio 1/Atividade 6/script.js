let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let valor3 = document.querySelector("#valor3");
let valor4 = document.querySelector("#valor4");
let h3Resultado = document.querySelector("#h3Resultado");

function mostrarMenor() {
    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);
    let num3 = Number(valor3.value);
    let num4 = Number(valor4.value);

    let menor = Math.min(num1, num2, num3, num4);

    h3Resultado.innerText = "O menor valor e: " + menor;
}
