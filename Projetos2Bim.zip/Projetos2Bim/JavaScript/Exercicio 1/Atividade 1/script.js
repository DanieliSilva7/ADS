let pago = document.querySelector ("#pago");
let preco = document.querySelector("#preco");
let h3resultado = document.querySelector("#h3resultado");
let btSomar = document.querySelector("#btSomar");

function trocarNumero () {
    let valorpago = Number (pago.value);
    let valorpreco = Number (preco.value);
    h3resultado.textContent = (valorpago-valorpreco);
}
btSomar.onclick = function(){
   trocarNumero();
}
