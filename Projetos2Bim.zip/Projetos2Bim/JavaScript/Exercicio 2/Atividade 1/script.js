let porcentagem1 = document.querySelector("#porcentagem1");
let somar = document.querySelector("#somar");
let Resultado1 = document.querySelector("#Resultado1");
let Resultado2 = document.querySelector("#Resultado2");
let Resultado3 = document.querySelector("#Resultado3");
let Resultado4 = document.querySelector("#Resultado4");

function Somar(){
    let num1 = Number(porcentagem1.value)

    Resultado1.textContent = (1 * num1 / 100) + num1;
    Resultado2.textContent = (2 * num1 / 100) + num1;
    Resultado3.textContent = (5 * num1 / 100) + num1;
    Resultado4.textContent = (10 * num1 / 100) + num1;
}

somar.onclick = function (){
    Somar();
}