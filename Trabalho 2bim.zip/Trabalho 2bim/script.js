
//////////////////////////(Exercicio Triangulo 1)////////////////////////////


document.addEventListener('DOMContentLoaded', () => {
    const sideXInput = document.getElementById('sideX');
    const sideYInput = document.getElementById('sideY');
    const sideZInput = document.getElementById('sideZ');
    const checkTriangleButton = document.getElementById('checkTriangle');
    const resultParagraph = document.getElementById('result');

    checkTriangleButton.addEventListener('click', () => {
        const x = parseFloat(sideXInput.value);
        const y = parseFloat(sideYInput.value);
        const z = parseFloat(sideZInput.value);


        if (isNaN(x) || isNaN(y) || isNaN(z) || x <= 0 || y <= 0 || z <= 0) {
            resultParagraph.textContent = 'Por favor, insira valores numéricos positivos para todos os lados.';
            resultParagraph.style.color = 'red';
            return;
        }


        if (x + y > z && x + z > y && y + z > x) {
            let triangleType = '';
            
            if (x === y && y === z) {
                triangleType = 'Equilátero';
            }
            
            else if (x === y || x === z || y === z) {
                triangleType = 'Isósceles';
            }
            
            else {
                triangleType = 'Escaleno';
            }
            resultParagraph.textContent = `Os valores formam um triângulo ${triangleType}.`;
            resultParagraph.style.color = 'green';
        } else {
            resultParagraph.textContent = 'Os valores NÃO formam um triângulo.';
            resultParagraph.style.color = 'red';
        }
    });
})



///////////////////////////(EXERCICIO IMC 2)/////////////////////////

document.addEventListener('DOMContentLoaded', function() {
    const calculateIMCButton = document.getElementById('calculateIMC');
    const weightInput = document.getElementById('weight');
    const heightInput = document.getElementById('height');
    const imcValueSpan = document.getElementById('imcValue');
    const imcClassificationSpan = document.getElementById('imcClassification');

    calculateIMCButton.addEventListener('click', function() {
        const weight = parseFloat(weightInput.value);
        const height = parseFloat(heightInput.value);

        if (isNaN(weight) || isNaN(height) || weight <= 0 || height <= 0) {
            imcValueSpan.textContent = '--';
            imcClassificationSpan.textContent = 'Por favor, insira valores válidos para peso e altura.';
            return;
        }

        const imc = weight / (height * height);
        let classification = '';

        if (imc < 18.5) {
            classification = 'Abaixo do peso';
        } else if (imc >= 18.5 && imc <= 24.9) {
            classification = 'Peso normal';
        } else if (imc >= 25 && imc <= 29.9) {
            classification = 'Sobrepeso';
        } else if (imc >= 30 && imc <= 34.9) {
            classification = 'Obesidade grau 1';
        } else if (imc >= 35 && imc <= 39.9) {
            classification = 'Obesidade grau 2';
        } else { // imc >= 40
            classification = 'Obesidade grau 3';
        }

        imcValueSpan.textContent = imc.toFixed(2); 
        imcClassificationSpan.textContent = classification;
    });
});


////////////////////////(CALCULADORA DE IMPOSTOS 3)/////////////////////////


////////////////////////(CALCULADORA DE SALARIO 4)/////////////////////////


////////////////////////(CALCULADORA DE CREDITO BANCARIO 5)/////////////////////////




////////////////////////(LANCHONETE 6)/////////////////////////
let CodigoItem = document.querySelector("#CodigoItem");
let QuantidadeItem = document.querySelector("#QuantidadeItem");
let TotalPedido = document.querySelector("#TotalPedido");
let CalcularPedido = document.querySelector("#CalcularPedido");

CalcularPedido.addEventListener("click", function () {
    let codigo = CodigoItem.value;
    let quantidade = Number(QuantidadeItem.value);
    let preco = 0;
    let nome = "";

    if (codigo === "1") {
        preco = 11;
        nome = "Cachorro Quente";
    } else if (codigo === "2") {
        preco = 8.5;
        nome = "Bauru";
    } else if (codigo === "3") {
        preco = 8;
        nome = "Misto Quente";
    } else if (codigo === "4") {
        preco = 9;
        nome = "Hamburguer";
    } else if (codigo === "5") {
        preco = 10;
        nome = "Cheeseburger";
    } else if (codigo === "6") {
        preco = 4.5;
        nome = "Refrigerante";
    } else {
        TotalPedido.textContent = "Código inválido.";
        return;
    }

    let total = preco * quantidade;

    TotalPedido.textContent = "Item: " + nome + " | Total a pagar: R$ " + total.toFixed(2);
});

////////////////////////(SISTEMA VENDAS 7)/////////////////////////

const precoEtiquetaInput = document.getElementById('precoEtiqueta');
const btnCalcular = document.getElementById('btnCalcular');
const precoFinalSpan = document.getElementById('precoFinal'); 
const condicaoPagamentoRadios = document.querySelectorAll('input[name="condicaoPagamento"]');
function calcularPrecoFinal() {  
    let precoNormal = Number(precoEtiquetaInput.value);
    let condicaoEscolhida = '';
    for (let i = 0; i < condicaoPagamentoRadios.length; i++) {
        if (condicaoPagamentoRadios[i].checked) { 
            condicaoEscolhida = condicaoPagamentoRadios[i].value; 
            break;
        }
    }
    let precoCalculado = precoNormal; 
    if (isNaN(precoNormal) || precoNormal <= 0) {
        precoFinalSpan.textContent = "R$ Erro: Preço inválido!";
        return; 
    }
    switch (condicaoEscolhida) {
        case 'a': 
            precoCalculado = precoNormal * 0.90;
            break;
        case 'b': 
            precoCalculado = precoNormal * 0.85; 
            break;
        case 'c': 
            break;
        case 'd': 
            precoCalculado = precoNormal * 1.10; 
            break;
        default:
            
            precoFinalSpan.textContent = "R$ Selecione uma condição de pagamento!";
            return; 
    }
    precoFinalSpan.textContent = `R$ ${precoCalculado.toFixed(2).replace('.', ',')}`;
}
btnCalcular.addEventListener('click', calcularPrecoFinal);

////////////////////////(SISTEMA DE PAGAMENTOS (ESCOLA) 8)/////////////////////////

const nivelProfessorSelect = document.getElementById('nivelProfessor');
const horasAulaInput = document.getElementById('horasAula');
const Calculater = document.getElementById('Calculater');
const salarioProfessorSpan = document.getElementById('salarioProfessor');

function calcularSalarioProfessor() {
    const nivel = nivelProfessorSelect.value; 
    let horasAula = Number(horasAulaInput.value); 
    let valorHoraAula = 0;

    switch (nivel) {
        case '1':
            valorHoraAula = 12.00;
            break;
        case '2':
            valorHoraAula = 17.00;
            break;
        case '3':
            valorHoraAula = 25.00;
            break;
        default:
           
            salarioProfessorSpan.textContent = "R$ Erro: Selecione o nível do professor.";
            return; 
    }
    if (isNaN(horasAula) || horasAula < 0) {
        salarioProfessorSpan.textContent = "R$ Erro: Insira horas/aula válidas.";
        return; 
    }

    let salarioSemanal = valorHoraAula * horasAula * 4.5;

    
    salarioProfessorSpan.textContent = `R$ ${salarioSemanal.toFixed(2).replace('.', ',')}`;
}

Calculater.addEventListener('click', calcularSalarioProfessor);





